%% Q3

predval = (mean(x) - mean(x)) * mean(groRate) + mean(y)
